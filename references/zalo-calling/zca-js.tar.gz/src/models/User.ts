import type { Gender } from "./Enum.js";
import type { ZBusinessPackage } from "./ZBusiness.js";

export type User = {
    userId: string;
    username: string;
    displayName: string;
    zaloName: string;
    avatar: string;
    bgavatar: string;
    cover: string;
    gender: Gender;
    dob: number;
    sdob: string;
    status: string;
    phoneNumber: string;
    isFr: number;
    isBlocked: number;
    lastActionTime: number;
    lastUpdateTime: number;
    isActive: number;
    key: number;
    type: number;
    isActivePC: number;
    isActiveWeb: number;
    isValid: number;
    userKey: string;
    accountStatus: number;
    oaInfo: unknown;
    user_mode: number;
    globalId: string;
    bizPkg: ZBusinessPackage;
    createdTs: number;
    oa_status: unknown;
};

export type UserBasic = {
    avatar: string;
    cover: string;
    status: string;
    gender: Gender;
    dob: number;
    sdob: string;
    globalId: string;
    bizPkg: ZBusinessPackage;
    uid: string;
    zalo_name: string;
    display_name: string;
};

export type UserSetting = {
    add_friend_via_contact: number;
    display_on_recommend_friend: number;
    add_friend_via_group: number;
    add_friend_via_qr: number;
    quick_message_status: number;
    show_online_status: boolean;
    accept_stranger_call: number;
    archived_chat_status: number;
    receive_message: number;
    add_friend_via_phone: number;
    display_seen_status: number;
    view_birthday: number;
    setting_2FA_status: number;
};

export type UnchangedProfileInfo = {
    oa_status: {
        blocked: number;
    };
    isFr: number;
    isBlocked: boolean;
    lastActionTime: number;
};
