import { ZaloApiError } from "../../Errors/ZaloApiError.js";
import { apiFactory, resolveResponse } from "../../utils.js";

import type { StickerDetail } from "../../models/index.js";

export type StickerDetailResponse = StickerDetail[];

export const getStickersDetailFactory = apiFactory<StickerDetailResponse>()((api, ctx, utils) => {
    const serviceURL = utils.makeURL(`${api.zpwServiceMap.sticker}/api/message/sticker/sticker_detail`);

    /**
     * Get stickers detail by sticker IDs
     *
     * @param stickerIds Sticker IDs to search for
     *
     * @throws {ZaloApiError}
     */
    return async function getStickersDetail(stickerIds: number | number[]) {
        if (!stickerIds) throw new ZaloApiError("Missing sticker id");
        if (!Array.isArray(stickerIds)) stickerIds = [stickerIds];
        if (stickerIds.length == 0) throw new ZaloApiError("Missing sticker id");

        const stickers: StickerDetailResponse = [];
        const tasks = stickerIds.map((stickerId) => getStickerDetail(stickerId));
        const tasksResult = await Promise.allSettled(tasks);
        tasksResult.forEach((result) => {
            if (result.status === "fulfilled") stickers.push(result.value);
        });

        return stickers;
    };

    async function getStickerDetail(stickerId: number) {
        const params = {
            sid: stickerId,
        };

        const encryptedParams = utils.encodeAES(JSON.stringify(params));
        if (!encryptedParams) throw new ZaloApiError("Failed to encrypt message");

        const response = await utils.request(
            utils.makeURL(serviceURL, {
                params: encryptedParams,
            }),
        );

        return resolveResponse<StickerDetail>(ctx, response);
    }
});
