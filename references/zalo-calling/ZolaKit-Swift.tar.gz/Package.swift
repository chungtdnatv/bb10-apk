// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "ZolaKit",
    platforms: [
        .iOS(.v16),
        .macOS(.v13),
    ],
    products: [
        .library(
            name: "ZolaKit",
            targets: ["ZolaKit"]
        ),
    ],
    targets: [
        // Single library, zero external dependencies.
        // Voice/video calling lives in Sources/ZolaKit/Call/.
        .target(
            name: "ZolaKit",
            dependencies: []
        ),
        .testTarget(
            name: "ZolaKitTests",
            dependencies: ["ZolaKit"]
        ),
        // Call signalling / media wire tests: `swift test --filter ZolaKitCallTests`.
        .testTarget(
            name: "ZolaKitCallTests",
            dependencies: ["ZolaKit"]
        ),
    ]
)
