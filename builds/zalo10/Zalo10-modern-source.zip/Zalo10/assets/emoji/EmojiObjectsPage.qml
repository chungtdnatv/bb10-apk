import bb.cascades 1.4

Container {
    signal emojiFilePicked(string file)

    property real pageWidth: 0
    property int  pageObjects: 0

    horizontalAlignment: HorizontalAlignment.Fill
    layoutProperties: StackLayoutProperties { spaceQuota: 1 }
    layout: StackLayout { orientation: LayoutOrientation.TopToBottom }

    Container {
        horizontalAlignment: HorizontalAlignment.Center
        preferredHeight: ui.du(2.5)
        layout: StackLayout { orientation: LayoutOrientation.LeftToRight }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 0
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 1
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 2
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 3
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 4
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 5
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 6
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 7
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 8
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pageObjects === 9
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
    }

    ScrollView {
        horizontalAlignment: HorizontalAlignment.Fill
        layoutProperties: StackLayoutProperties { spaceQuota: 1 }
        scrollViewProperties {
            scrollMode: ScrollMode.Horizontal
            pinchToZoomEnabled: false
        }
        onViewableAreaChanging: {
            if (pageWidth > 0) {
                var pg = Math.round(viewableArea.x / pageWidth);
                if (pg < 0) pg = 0;
                if (pg >= 10) pg = 10 - 1;
                pageObjects = pg;
            }
        }
        Container {
            layout: StackLayout { orientation: LayoutOrientation.LeftToRight }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f38d_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f49d_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f38e_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f392_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f393_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f38f_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f390_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f383_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f47b_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f385_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f384_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f381_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f389_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f388_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f38c_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3a5_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4f7_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4fc_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4bf_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4c0_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4bd_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4be_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4bb_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4f1_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_260e_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4de_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4e0_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4e1_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4fa_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4fb_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f508_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f514_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4e2_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4e3_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f513_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f512_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f50f_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f510_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f511_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f50e_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a1_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f50d_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f6c0_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f6bd_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f528_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f6ac_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a3_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f52b_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f48a_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f489_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4b0_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4b4_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4b5_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4f2_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_2709_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4e9_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4e8_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4eb_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4ea_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4ec_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f4ed_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4ee_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4dd_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_2702_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4d6_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3a8_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3ac_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3a4_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3a7_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3bc_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3b5_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3b6_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f3ba_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3b7_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3b8_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f47e_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f004_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3af_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3c8_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3c0_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_26bd_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_26be_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3be_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3b1_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_26f3_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3c1_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3c6_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3bf_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_2615_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f375_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f376_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f37a_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f37b_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f378_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f374_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f354_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f35f_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f35d_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f35b_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f371_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f363_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f359_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f358_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f35a_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f35c_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f372_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f362_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f361_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f373_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f35e_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f366_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f367_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f370_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f34e_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f34a_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f349_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f353_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f346_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f345_64.png"; emojiCategory: "objects"; onEmojiTapped: { emojiFilePicked(file) } }
            }
        }
    }
}
