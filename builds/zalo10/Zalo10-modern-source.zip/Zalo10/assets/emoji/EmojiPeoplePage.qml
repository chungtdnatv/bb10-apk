import bb.cascades 1.4

Container {
    signal emojiFilePicked(string file)

    property real pageWidth: 0
    property int  pagePeople: 0

    horizontalAlignment: HorizontalAlignment.Fill
    layoutProperties: StackLayoutProperties { spaceQuota: 1 }
    layout: StackLayout { orientation: LayoutOrientation.TopToBottom }

    Container {
        horizontalAlignment: HorizontalAlignment.Center
        preferredHeight: ui.du(2.5)
        layout: StackLayout { orientation: LayoutOrientation.LeftToRight }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 0
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 1
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 2
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 3
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 4
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 5
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 6
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 7
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 8
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 9
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 10
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
        ImageView {
            preferredWidth: ui.du(1.2); preferredHeight: ui.du(1.2)
            verticalAlignment: VerticalAlignment.Center
            leftMargin: ui.du(0.2); rightMargin: ui.du(0.2)
            imageSource: pagePeople === 11
                ? "asset:///images/ChatView/emoji/activePageDot.png"
                : "asset:///images/ChatView/emoji/inactivePageDot.png"
        }
    }

    ScrollView {
        horizontalAlignment: HorizontalAlignment.Fill
        layoutProperties: StackLayoutProperties { spaceQuota: 1 }
        scrollViewProperties {
            scrollMode: ScrollMode.Horizontal
            pinchToZoomEnabled: false
        }
        onViewableAreaChanging: {
            if (pageWidth > 0) {
                var pg = Math.round(viewableArea.x / pageWidth);
                if (pg < 0) pg = 0;
                if (pg >= 12) pg = 12 - 1;
                pagePeople = pg;
            }
        }
        Container {
            layout: StackLayout { orientation: LayoutOrientation.LeftToRight }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f604_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f603_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_263a_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f609_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f60d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f618_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f61a_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f61c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f61d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f633_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f601_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f614_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f60c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f612_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f61e_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f623_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f622_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f602_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f62d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f62a_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f625_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f630_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f613_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f629_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f62b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f628_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f631_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f620_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f621_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f624_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f616_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f606_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f60b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f637_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f635_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f632_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f47f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f60f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f472_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f473_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f46e_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f477_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f482_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f476_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f466_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f467_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f468_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f469_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f474_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f475_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f471_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f47c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f478_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f63a_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f638_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f63b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f63d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f63c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f640_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f63f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f639_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f480_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f47d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a9_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f525_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_2728_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f31f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a2_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a6_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a7_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a4_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4a8_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f442_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f440_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f443_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f445_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f444_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f44d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f44e_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f44c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f44a_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_270a_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_270c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f44b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f64b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f450_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f446_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f447_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f449_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f448_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f64c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_261d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f64f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f44f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4aa_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f483_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f46b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f48f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f491_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f46f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f64b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f485_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f64d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f3a9_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f451_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f452_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f45f_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f461_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f460_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f462_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f455_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f454_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f457_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f458_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f459_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f4bc_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f45c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f380_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f302_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f484_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f49b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f499_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f49c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f49a_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_2764_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f494_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f497_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f493_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f496_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f49e_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f498_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f48c_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
            }
            Container {
                preferredWidth: pageWidth > 0 ? pageWidth : ui.du(52)
                layout: GridLayout { columnCount: 6 }
                horizontalAlignment: HorizontalAlignment.Fill
                topPadding: ui.du(0.5); bottomPadding: ui.du(0.5); leftPadding: ui.du(1); rightPadding: ui.du(1)
                EmojiButton { emojiFile: "emoji_1f48b_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f48d_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                EmojiButton { emojiFile: "emoji_1f48e_64.png"; emojiCategory: "people"; onEmojiTapped: { emojiFilePicked(file) } }
                Container {
                    preferredHeight: ui.du(7); maxHeight: ui.du(7); maxWidth: ui.du(7.5)
                    opacity: 0
                    touchPropagationMode: TouchPropagationMode.None
                }
                Container {
                    preferredHeight: ui.du(7); maxHeight: ui.du(7); maxWidth: ui.du(7.5)
                    opacity: 0
                    touchPropagationMode: TouchPropagationMode.None
                }
                Container {
                    preferredHeight: ui.du(7); maxHeight: ui.du(7); maxWidth: ui.du(7.5)
                    opacity: 0
                    touchPropagationMode: TouchPropagationMode.None
                }
            }
        }
    }
}
